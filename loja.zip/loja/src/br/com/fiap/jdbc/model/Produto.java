package br.com.fiap.jdbc.model;

public class Produto { // rela��o com a tabela Categoria

	private int idProduto; // pk
	private int idCategoria; // fk
	private String nome;
	private String descricao;
	
	// construtor (para id)
	public Produto(int idProduto, String nome, String descricao) {
		this.idProduto = idProduto;
		this.nome = nome;
		this.descricao = descricao;
	}
	
	// construtor (apenas para nome e descri��o)
	public Produto(String nome, String descricao) {
		this.nome = nome;
		this.descricao = descricao;
	}
	
	// getters e setters
	public int getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(int idProduto) {
		this.idProduto = idProduto;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	@Override
	public String toString() { // customiza��o da exibi��o dos dados da classe
		return String.format("O produto � %d, %s, %s", this.idProduto, this.nome, this.descricao);
	}
	
}
