package br.com.fiap.jdbc.model;

import java.util.ArrayList;
import java.util.List;

public class Categoria { // rela��o com a tabela Produto
	
	private int idCategoria; // pk
	private String nome;
	private List<Produto> produtos = new ArrayList<Produto>();
	
	// construtor vazio
	public Categoria() {
		
	}
	
	// getters e setters
	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void adicionar(Produto produto) {
		produtos.add(produto);
	}
	
	public List<Produto> getProdutos() {
		return produtos;
	}
	
	@Override
	public String toString() { // customiza��o da exibi��o dos dados da classe
		return String.format("O produto � %d, %s", this.idCategoria, this.nome);
	}
	
}
