package br.com.fiap.jdbc;

public class JavaDataBaseConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
