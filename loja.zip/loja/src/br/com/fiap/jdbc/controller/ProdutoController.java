package br.com.fiap.jdbc.controller;

import java.sql.Connection;
import java.util.List;

import br.com.fiap.jdbc.dao.ProdutoDAO;
import br.com.fiap.jdbc.factory.ConnectionFactory;
import br.com.fiap.jdbc.model.Categoria;
import br.com.fiap.jdbc.model.Produto;

public class ProdutoController {

	private ProdutoDAO produtoDAO;

	public ProdutoController() {
		Connection connection = new ConnectionFactory().conectarOracle();
		produtoDAO = new ProdutoDAO(connection);
	}

	public List<Produto> listarDAO() {
		return produtoDAO.listar();
	}

	public void salvarDAO(Produto produto) {
		produtoDAO.salvar(produto);
	}

	public void salvarComCategoriaDAO(Produto produto) {
		produtoDAO.salvarComCategoria(produto);
	}

	public void alterarDAO(String nome, String descricao, Integer id) {
		produtoDAO.alterar(nome, descricao, id);
	}

	public List<Produto> buscarDAO(Categoria ct) {
		return produtoDAO.buscar(ct);
	}

	public void deletarDAO(Integer idProduto) {
		produtoDAO.deletar(idProduto);
	}

}
