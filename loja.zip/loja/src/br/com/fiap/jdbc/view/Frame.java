package br.com.fiap.jdbc.view;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import br.com.fiap.jdbc.controller.CategoriaController;
import br.com.fiap.jdbc.controller.ProdutoController;
import br.com.fiap.jdbc.model.Categoria;
import br.com.fiap.jdbc.model.Produto;

public class Frame extends JFrame {

	public static void main(String[] args) {
		try {
			Frame frame = new Frame();
			frame.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// private JPanel contentPane;
	private static final long serialVersionUID = 1L;
	private JTextField txtNome, txtDescricao;
	private JLabel lbNome, lbDescricao, lbCategoria;
	private JComboBox<Categoria> comboCategoria;
	private JButton btnSalvar, btnEditar, btnLimpar, btnApagar;
	private JTable table;
	private DefaultTableModel model;
	private CategoriaController categoriaController;
	private ProdutoController produtoController;

	public Frame() throws SQLException {
		super("Lista de Produtos");
		Container container = getContentPane();
		setLayout(null);

		categoriaController = new CategoriaController();
		produtoController = new ProdutoController();

		lbNome = new JLabel("Nome");
		lbDescricao = new JLabel("Descri��o");
		lbCategoria = new JLabel("Categoria");

		lbNome.setBounds(10, 10, 240, 15);
		lbDescricao.setBounds(10, 50, 240, 15);
		lbCategoria.setBounds(10, 90, 240, 15);

		lbNome.setForeground(Color.BLUE);
		lbDescricao.setForeground(Color.BLUE);
		lbCategoria.setForeground(Color.BLUE);

		container.add(lbNome);
		container.add(lbDescricao);
		container.add(lbCategoria);

		txtNome = new JTextField();
		txtDescricao = new JTextField();
		comboCategoria = new JComboBox<Categoria>();

		List<Categoria> categorias = categoriaController.listarDAO();
		for (Categoria categoria : categorias) {
			comboCategoria.addItem(categoria);
		}

		txtNome.setBounds(10, 25, 265, 20);
		txtDescricao.setBounds(10, 65, 265, 20);
		comboCategoria.setBounds(10, 105, 265, 20);

		container.add(txtNome);
		container.add(txtDescricao);
		container.add(comboCategoria);

		btnSalvar = new JButton("Salvar");
		btnLimpar = new JButton("Limpar");

		btnSalvar.setBounds(10, 145, 80, 20);
		btnLimpar.setBounds(100, 145, 80, 20);

		container.add(btnSalvar);
		container.add(btnLimpar);

		table = new JTable();
		model = (DefaultTableModel) table.getModel();

		model.addColumn("Identificador");
		model.addColumn("Nome");
		model.addColumn("Descri��o");

		preencherTabela();

		table.setBounds(10, 185, 760, 300);
		container.add(table);

		btnApagar = new JButton("Excluir");
		btnEditar = new JButton("Alterar");

		btnApagar.setBounds(10, 500, 80, 20);
		btnEditar.setBounds(100, 500, 80, 20);

		container.add(btnApagar);
		container.add(btnEditar);

		setSize(800, 600);
		setVisible(true);
		setLocationRelativeTo(null);

		btnSalvar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				salvar();
				limparTabela();
				preencherTabela();
			}
		});

		btnEditar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				alterar();
				limparTabela();
				preencherTabela();
			}
		});

		btnLimpar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				limpar();
			}
		});

		btnApagar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				excluir();
				limparTabela();
				preencherTabela();
			}
		});
	}

	private void salvar() {
		if (!txtNome.getText().equals("") && !txtDescricao.getText().equals("")) {
			Produto produto = new Produto(txtNome.getText(), txtDescricao.getText());
			Categoria categoria = (Categoria) comboCategoria.getSelectedItem();
			produto.setIdCategoria(categoria.getIdCategoria());
			this.produtoController.salvarComCategoriaDAO(produto);
			JOptionPane.showMessageDialog(this, "Salvo com sucesso!");
			this.limpar();
		} else {
			JOptionPane.showMessageDialog(this, "Nome e Descri��o devem ser informados.");
		}
	}

	private List<Produto> listarProduto() {
		return this.produtoController.listarDAO();
	}

	private void alterar() {
		Object object = (Object) model.getValueAt(table.getSelectedRow(), table.getSelectedColumn());
		if (object instanceof Integer) {
			Integer id = (Integer) object;
			String nome = (String) model.getValueAt(table.getSelectedRow(), 1);
			String descricao = (String) model.getValueAt(table.getSelectedRow(), 2);
			this.produtoController.alterarDAO(nome, descricao, id);
			JOptionPane.showMessageDialog(this, "Item alterado com sucesso!");
		} else {
			JOptionPane.showMessageDialog(this, "Selecionar o ID");
		}
	}

	private void excluir() {
		Object object = (Object) model.getValueAt(table.getSelectedRow(), table.getSelectedColumn());
		if (object instanceof Integer) {
			Integer id = (Integer) object;
			this.produtoController.deletarDAO(id);
			model.removeRow(table.getSelectedRow());
			JOptionPane.showMessageDialog(this, "Item exclu�do com sucesso!");
		} else {
			JOptionPane.showMessageDialog(this, "Selecionar o ID");
		}
	}

	private void limparTabela() {
		model.getDataVector().clear();
	}

	private void preencherTabela() {
		List<Produto> produtos = listarProduto();
		try {
			for (Produto produto : produtos) {
				model.addRow(new Object[] { produto.getIdCategoria(), produto.getNome(), produto.getDescricao() });
			}
		} catch (Exception e) {
			throw e;
		}
	}

	private void limpar() {
		this.txtNome.setText("");
		this.txtDescricao.setText("");
		this.comboCategoria.setSelectedIndex(0);
	}

}
